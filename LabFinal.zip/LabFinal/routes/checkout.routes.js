const express = require("express");
const Order = require("../models/order.model");
const { checkCartNotEmpty } = require("../middleware/cart.middleware");

const router = express.Router();
const customerName = req.body.customerName;
const email = req.body.email;

// SHOW CHECKOUT PAGE
router.get("/checkout", checkCartNotEmpty, (req, res) => {
  res.render("checkout", {
    cart: req.session.cart,
  });
});

// PLACE ORDER
router.post("/checkout", checkCartNotEmpty, async (req, res) => {
  try {
    const { customerName, email } = req.body;

    const order = new Order({
      customerName,
      email,
      items: req.session.cart.items,
      totalAmount: req.session.cart.total,
    });

    await order.save();

    // clear cart
    req.session.cart = null;

    res.redirect(`/order-confirmation/${order._id}`);
  } catch (err) {
    res.status(500).send("Order failed");
  }
});

if (!customerName || !email) {
  return res.status(400).send("All fields required");
}

router.get("/order-confirmation/:id", (req, res) => {
  res.render("order-confirmation", { orderId: req.params.id });
});

module.exports = router;
